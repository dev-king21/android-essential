![App Icon](https://raw.github.com/ekaputra07/quick-sms/master/logo/144.png)

# Quick SMS Android
Android app to create and send predefined SMS messages easily.

<img src="https://raw.github.com/ekaputra07/quick-sms/master/screenshots/new/home.png" width="400px"/>
<img src="https://raw.github.com/ekaputra07/quick-sms/master/screenshots/new/multiple-recipients.png" width="400px"/>


## Get it on Google Play!
[https://play.google.com/store/apps/details?id=com.balicodes.quicksms](https://play.google.com/store/apps/details?id=com.balicodes.quicksms&utm_source=GitHub)

As per March 2019 this app not available anymore on Google Play, if you want it you need to download it directly from here [https://github.com/ekaputra07/quick-sms/releases](https://github.com/ekaputra07/quick-sms/releases)

## Icon

App icon by [Md Masud Rana](https://github.com/maaudrana)
