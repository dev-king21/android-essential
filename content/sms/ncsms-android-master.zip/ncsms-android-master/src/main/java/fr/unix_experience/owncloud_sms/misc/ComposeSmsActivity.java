package fr.unix_experience.owncloud_sms.misc;

import android.app.Activity;

public class ComposeSmsActivity extends Activity {
}
