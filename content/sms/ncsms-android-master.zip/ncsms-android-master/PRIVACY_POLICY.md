# Overview

Nextcloud SMS is a free software developed by its contributors. This privacy policy
is intended to inform you about data gathered by this application."

# Information we collect

Only SMS and call log are collected by the application.

# Where information is sent.

Information is neither sent to Nextcloud team servers nor Nextcloud SMS team servers nor
any government nor another entity you don't want.

When you configure a Nextcloud account in the application, you agree with the Nextcloud
instance owner that your SMS and call log data will be stored in his infrastructure
under his responsibility.

We __don't__ recommend to use a public or a company Nextcloud instance account. Your privacy
must be under your control on your own Nextcloud instance.
