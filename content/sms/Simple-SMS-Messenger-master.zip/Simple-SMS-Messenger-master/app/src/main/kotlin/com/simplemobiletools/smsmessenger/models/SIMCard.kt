package com.simplemobiletools.smsmessenger.models

data class SIMCard(val id: Int, val subscriptionId: Int, val label: String)
