package com.simplemobiletools.smsmessenger.models

data class ThreadSending(val messageId: Long) : ThreadItem()
