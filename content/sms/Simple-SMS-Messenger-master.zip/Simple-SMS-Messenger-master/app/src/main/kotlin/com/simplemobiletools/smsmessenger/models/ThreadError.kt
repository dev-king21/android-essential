package com.simplemobiletools.smsmessenger.models

data class ThreadError(val messageId: Long, val messageText: String) : ThreadItem()
