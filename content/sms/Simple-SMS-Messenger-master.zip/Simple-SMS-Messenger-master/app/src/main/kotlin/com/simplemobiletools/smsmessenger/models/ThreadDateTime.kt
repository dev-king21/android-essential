package com.simplemobiletools.smsmessenger.models

open class ThreadDateTime(val date: Int, val simID: String) : ThreadItem()
