package com.simplemobiletools.smsmessenger.models

open class ThreadItem
