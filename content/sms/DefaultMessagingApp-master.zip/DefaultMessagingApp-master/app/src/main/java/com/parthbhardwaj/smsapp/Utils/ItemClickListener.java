package com.parthbhardwaj.smsapp.Utils;

public interface ItemClickListener {

        void itemClicked(String contact,long id,String read,);
}
