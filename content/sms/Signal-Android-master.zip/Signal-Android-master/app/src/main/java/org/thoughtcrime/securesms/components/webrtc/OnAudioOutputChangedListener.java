package org.thoughtcrime.securesms.components.webrtc;

public interface OnAudioOutputChangedListener {
  void audioOutputChanged(WebRtcAudioOutput audioOutput);
}
