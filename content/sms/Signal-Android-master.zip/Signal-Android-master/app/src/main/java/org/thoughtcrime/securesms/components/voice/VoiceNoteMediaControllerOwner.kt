package org.thoughtcrime.securesms.components.voice

interface VoiceNoteMediaControllerOwner {
  val voiceNoteMediaController: VoiceNoteMediaController
}
