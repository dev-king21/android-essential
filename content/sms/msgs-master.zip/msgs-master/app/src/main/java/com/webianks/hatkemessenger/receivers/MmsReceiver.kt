package com.webianks.hatkemessenger.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Created by R Ankit on 24-12-2016.
 */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {}
}