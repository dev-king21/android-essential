The files in this package were copied from the android-4.4.4_r1 branch of ASOP from the folders
com/android/camera/ and com/android/camera/ui from files with the same name.  Some modifications
have been made to remove unneeded features and adjust to our needs.