/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.messaging.util;

import android.content.Context;

/**
 * A thin wrapper for getting GServices value.
 */
public class BugleGservicesImpl extends BugleGservices {
    public BugleGservicesImpl(final Context context) {
    }

    @Override
    public void registerForChanges(final Runnable r) {
    }

    /**
     * Asserts that the key has the expected prefix.
     */
    private void assertKeyAndWaitForGservices(final String key) {
        Assert.isTrue(key.startsWith(BUGLE_GSERVICES_PREFIX));
    }

    @Override
    public long getLong(final String key, final long defaultValue) {
        assertKeyAndWaitForGservices(key);
        return defaultValue;
    }

    @Override
    public int getInt(final String key, final int defaultValue) {
        assertKeyAndWaitForGservices(key);
        return defaultValue;
    }

    @Override
    public boolean getBoolean(final String key, final boolean defaultValue) {
        assertKeyAndWaitForGservices(key);
        return defaultValue;
    }

    @Override
    public String getString(final String key, final String defaultValue) {
        assertKeyAndWaitForGservices(key);
        return defaultValue;
    }

    @Override
    public float getFloat(final String key, final float defaultValue) {
        assertKeyAndWaitForGservices(key);
        return defaultValue;
    }
}
