package com.moez.QKSMS.manager

interface ReferralManager {

    suspend fun trackReferrer()

}
