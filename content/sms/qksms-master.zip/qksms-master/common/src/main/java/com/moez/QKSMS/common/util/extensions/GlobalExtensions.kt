package com.moez.QKSMS.common.util.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
