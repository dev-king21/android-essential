## Author
__Marvin Blase__ 
[Blog](www.beautifycode.com "Homepage")
[Twitter](www.twitter.com/@beautifycode "Twitter")


## About
Creates a P2P Connection via Stratus between anyone who is running the Client.swf and someone who is starting this Android App on his mobile. This means you can exchange data in realtime without Wi-Fi, Bluetooth or the like. Comes especially handy in using it for remote stuff or as HID.

## License
Copyright (c) <2010> <copyright holders>
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
