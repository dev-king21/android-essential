# SWF-Decompiler_android
Android SWF decompiler

This application diecompiles a swf file to actionscript files using a [jpexs-decompiler library](https://github.com/jindrapetrik/jpexs-decompiler).